import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom';
import axios from "axios";
// import toast from 'react-hot-toast';
import './ViewStyle.css';

const View = () => {
    const users = {
        fname: "",
        lname: "",
        email: ""
    }
    const { id } = useParams();
    // const navigate = useNavigate();
    const [user, setUser] = useState(users);


    useEffect(() => {
        axios.get(`http://localhost:8000/api/getone/${id}`)
            .then((response) => {
                setUser(response.data)
            })
            .catch((error) => {
                console.log(error);
            })
    }, [id])

    return (
        <>
            <section>
                <div className="card">
                    <div className="link">
                        <Link to={"/"}>Back</Link>
                        <h3>View user</h3>
                    </div>
                    <h2>Name: {user.lname}</h2>
                    <p>Email: {user.email}</p>
                </div>
            </section>
        </>
    )
}

export default View;
